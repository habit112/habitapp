using HabitApp.Models;
using HabitApp.Services.Implementations;
using HabitApp.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using MongoDB.Bson;
using System.Collections.Generic;

namespace HabitApp.Pages
{
    public class AdminAllocatePointsModel : PageModel
    {
        [BindProperty]
        public IEnumerable<HabitModel> HabitDataModels { get; set; }

        public void OnGet()
        {
            IViewHabit viewHabitService = new ViewHabitImpl();
            HabitDataModels = viewHabitService.getHabitModels(ObjectId.Parse("61e4c057dd0bc07d571c967c"));
        }


        public IActionResult OnPost()
        {
            IAllocatePoints addPointService = new AllocatePointsImpl();
            HabitModel HabitData = new HabitModel();

            bool isSucess = addPointService.addPoints(HabitData);

            if (isSucess)
            {
                return RedirectToPage("/adminview");
            }

            return null;
        }
    }
}
