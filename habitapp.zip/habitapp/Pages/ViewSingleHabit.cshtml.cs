using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HabitApp.Pages
{
    public class ViewSingleHabitModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
