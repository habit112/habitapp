﻿using HabitApp.Models;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HabitApp.DBHandler.Childerns
{
    public class AllocatePointDataHandler : DBHandler
    {
        public AllocatePointDataHandler(String collectionName) : base(collectionName)
        {

        }


        public Task<bool> AdminAllocatePoints(HabitModel habit)
        {
            bool status = false;

            Task addPointTask = collection.InsertOneAsync(habit.ToBsonDocument());

            addPointTask.Wait();

            if (addPointTask.IsCompleted)
            {
                status = true;
            }
            else
            {
                status = false;
            }

            return Task.FromResult(status);
        }
    }
}
